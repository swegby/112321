"""
yu.nails — Telegram бот + Mini App backend
FastAPI + aiogram (Telegram Bot API) + SQLite

Возможности:
  — запись клиентов (только с 16:00 по умолчанию, настраивается)
  — напоминания за 24ч и 2ч до визита
  — админ-панель (Mini App) с дашбордом, записями, расписанием, прайсом
  — несколько админов (главный в .env + /addadmin в боте)
  — автосинхронизация с Telegram: бот присылает уведомления, инлайн-кнопки
"""
import os
import asyncio
import logging
import json
from datetime import datetime, timedelta
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, List
import aiosqlite
from dotenv import load_dotenv

from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import (
    InlineKeyboardButton, InlineKeyboardMarkup,
    WebAppInfo, MenuButtonWebApp, BotCommand
)
from apscheduler.schedulers.asyncio import AsyncIOScheduler

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://example.com")
ADMIN_PANEL_URL = os.getenv("ADMIN_PANEL_URL", "https://example.com/admin.html")
ADMIN_TG_ID = int(os.getenv("ADMIN_TG_ID", "0"))  # главный админ
DATABASE = os.getenv("DATABASE", "./data.db")

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("yunails")

# ============== БАЗА ДАННЫХ ==============
DB_SCHEMA = """
CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service TEXT NOT NULL,
    service_id TEXT,
    design TEXT,
    design_price INTEGER DEFAULT 0,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    name TEXT NOT NULL,
    username TEXT,
    tg_id INTEGER NOT NULL,
    photo_url TEXT,
    comment TEXT,
    price INTEGER NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at TEXT NOT NULL,
    notified_24h INTEGER DEFAULT 0,
    notified_2h INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS clients (
    tg_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    last_name TEXT,
    phone TEXT,
    visits INTEGER DEFAULT 0,
    last_visit TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS services (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    price INTEGER NOT NULL,
    duration INTEGER DEFAULT 60,
    description TEXT,
    is_addon INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    active INTEGER DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS schedule (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    day_of_week INTEGER NOT NULL,  -- 0=пн, 6=вс
    start_time TEXT NOT NULL,       -- "16:00"
    end_time TEXT NOT NULL,         -- "21:00"
    active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS blocked_slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    reason TEXT,
    created_at TEXT NOT NULL,
    UNIQUE(date, time)
);

CREATE TABLE IF NOT EXISTS admins (
    tg_id INTEGER PRIMARY KEY,
    username TEXT,
    added_by INTEGER,
    added_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_bookings_tg_id ON bookings(tg_id);
CREATE INDEX IF NOT EXISTS idx_bookings_date ON bookings(date);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
"""

# дефолтные настройки
DEFAULT_SETTINGS = {
    "default_start_time": "16:00",
    "default_end_time": "21:00",
    "slot_duration_min": 60,
    "reminder_24h": "1",
    "reminder_2h": "1",
    "booking_lead_hours": "2",  # нельзя записаться менее чем за 2 часа
}

DEFAULT_SERVICES = [
    ("combo", "комбинированный маникюр", 500, 60, "аппарат + классика. кутикула, форма, шлифовка.", 0, 1, 1),
    ("cover", "маникюр с покрытием", 1000, 90, "гель-лак под кутикулу. носится 3-4 недели.", 0, 2, 1),
    ("fix", "коррекция покрытия", 1200, 90, "спил, выравнивание, новое покрытие.", 0, 3, 1),
    ("design-simple", "лёгкий дизайн", 0, 15, "фольга, втирка, слайдеры, акценты до 2 ногтей.", 1, 4, 1),
    ("design-hard", "сложный дизайн", 200, 30, "роспись, объём, акварель, инкрустация.", 1, 5, 1),
]

# дефолтное расписание: пн-вс с 16:00 до 21:00
DEFAULT_SCHEDULE = [
    (0, "16:00", "21:00", 1),  # пн
    (1, "16:00", "21:00", 1),  # вт
    (2, "16:00", "21:00", 1),  # ср
    (3, "16:00", "21:00", 1),  # чт
    (4, "16:00", "21:00", 1),  # пт
    (5, "16:00", "21:00", 1),  # сб
    (6, "16:00", "21:00", 0),  # вс (выходной по умолчанию)
]


async def init_db():
    async with aiosqlite.connect(DATABASE) as db:
        await db.executescript(DB_SCHEMA)
        # заполняем дефолтные услуги
        for s in DEFAULT_SERVICES:
            await db.execute("""
                INSERT OR IGNORE INTO services (id, name, price, duration, description, is_addon, sort_order, active, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (*s, datetime.now().isoformat()))
        # заполняем расписание
        for sch in DEFAULT_SCHEDULE:
            await db.execute("""
                INSERT OR IGNORE INTO schedule (id, day_of_week, start_time, end_time, active)
                VALUES ((SELECT MAX(id)+1 FROM schedule WHERE day_of_week=?), ?, ?, ?, ?)
            """, (sch[0], *sch))
        # настройки
        for k, v in DEFAULT_SETTINGS.items():
            await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))
        # главный админ
        if ADMIN_TG_ID:
            await db.execute("INSERT OR IGNORE INTO admins (tg_id, added_at) VALUES (?, ?)",
                          (ADMIN_TG_ID, datetime.now().isoformat()))
        await db.commit()
    log.info("DB initialized")


async def get_setting(key: str, default: str = None) -> str:
    async with aiosqlite.connect(DATABASE) as db:
        cur = await db.execute("SELECT value FROM settings WHERE key = ?", (key,))
        row = await cur.fetchone()
    return row[0] if row else (default or DEFAULT_SETTINGS.get(key, ""))


async def get_db():
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        return db


# ============== АВТОРИЗАЦИЯ АДМИНА ==============
async def is_admin(tg_id: int) -> bool:
    if tg_id == ADMIN_TG_ID:
        return True
    async with aiosqlite.connect(DATABASE) as db:
        cur = await db.execute("SELECT 1 FROM admins WHERE tg_id = ?", (tg_id,))
        row = await cur.fetchone()
    return bool(row)


async def require_admin(tg_id: int) -> bool:
    if not await is_admin(tg_id):
        raise HTTPException(status_code=403, detail="forbidden")
    return True


# ============== TELEGRAM BOT ==============
bot = Bot(token=BOT_TOKEN) if BOT_TOKEN else None
dp = Dispatcher() if bot else None
scheduler = AsyncIOScheduler()


@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    """Приветствие с кнопкой WebApp"""
    if not bot: return
    user = message.from_user
    is_user_admin = await is_admin(user.id)

    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("""
            INSERT INTO clients (tg_id, username, first_name, last_name, created_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(tg_id) DO UPDATE SET
                username=excluded.username,
                first_name=excluded.first_name,
                last_name=excluded.last_name
        """, (user.id, user.username, user.first_name, user.last_name, datetime.now().isoformat()))
        await db.commit()

    if is_user_admin:
        # для админа — две кнопки: запись и админка
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✦ записаться", web_app=WebAppInfo(url=WEBAPP_URL))],
            [InlineKeyboardButton(text="🎛 админ-панель", web_app=WebAppInfo(url=ADMIN_PANEL_URL))],
            [InlineKeyboardButton(text="📢 telegram канал", url="https://t.me/yulkawxxxx")],
        ])
        await message.answer(
            f"привет, <b>{user.first_name}</b>! ✦\n\n"
            "ты вошёл как <b>администратор</b>.\n"
            "тебе доступна админ-панель для управления записями, расписанием и прайсом.",
            reply_markup=kb,
            parse_mode="HTML"
        )
    else:
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✦ записаться", web_app=WebAppInfo(url=WEBAPP_URL))],
            [InlineKeyboardButton(text="📢 telegram канал", url="https://t.me/yulkawxxxx")],
        ])
        await message.answer(
            f"привет, {user.first_name}! ✦\n\n"
            "я — бот студии маникюра <b>yu.nails</b>.\n"
            "нажми кнопку ниже, чтобы записаться:",
            reply_markup=kb,
            parse_mode="HTML"
        )


@dp.message(Command("admin"))
async def cmd_admin(message: types.Message):
    """Открыть админ-панель"""
    if not await is_admin(message.from_user.id):
        return
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎛 открыть админ-панель", web_app=WebAppInfo(url=ADMIN_PANEL_URL))]
    ])
    await message.answer(
        "🎛 <b>админ-панель yu.nails</b>\n\n"
        "в панели ты можешь:\n"
        "• смотреть статистику и выручку\n"
        "• управлять всеми записями\n"
        "• менять расписание (время работы)\n"
        "• редактировать прайс и услуги\n"
        "• блокировать слоты",
        reply_markup=kb,
        parse_mode="HTML"
    )


@dp.message(Command("addadmin"))
async def cmd_addadmin(message: types.Message):
    """Добавить админа (только главный админ)"""
    if message.from_user.id != ADMIN_TG_ID:
        return
    args = message.text.split()
    if len(args) < 2:
        await message.answer("использование: <code>/addadmin @username</code> или <code>/addadmin 123456789</code>", parse_mode="HTML")
        return
    target = args[1].lstrip('@')
    tg_id = None
    if target.isdigit():
        tg_id = int(target)
    else:
        # ищем по username
        async with aiosqlite.connect(DATABASE) as db:
            cur = await db.execute("SELECT tg_id FROM clients WHERE username = ?", (target,))
            row = await cur.fetchone()
        if row:
            tg_id = row[0]
    if not tg_id:
        await message.answer("❌ не нашёл пользователя. он должен сначала написать /start боту.")
        return
    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("INSERT OR IGNORE INTO admins (tg_id, added_by, added_at) VALUES (?, ?, ?)",
                      (tg_id, message.from_user.id, datetime.now().isoformat()))
        await db.commit()
    await message.answer(f"✅ админ @{target} (id {tg_id}) добавлен")


@dp.message(Command("deladmin"))
async def cmd_deladmin(message: types.Message):
    if message.from_user.id != ADMIN_TG_ID:
        return
    args = message.text.split()
    if len(args) < 2:
        await message.answer("использование: <code>/deladmin @username</code> или <code>/deladmin 123456789</code>", parse_mode="HTML")
        return
    target = args[1].lstrip('@')
    if target.isdigit():
        tg_id = int(target)
    else:
        async with aiosqlite.connect(DATABASE) as db:
            cur = await db.execute("SELECT tg_id FROM clients WHERE username = ?", (target,))
            row = await cur.fetchone()
        tg_id = row[0] if row else None
    if not tg_id:
        await message.answer("❌ не нашёл")
        return
    if tg_id == ADMIN_TG_ID:
        await message.answer("❌ нельзя удалить главного админа")
        return
    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("DELETE FROM admins WHERE tg_id = ?", (tg_id,))
        await db.commit()
    await message.answer(f"✅ админ {tg_id} удалён")


@dp.message(Command("today"))
async def cmd_today(message: types.Message):
    if not await is_admin(message.from_user.id): return
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM bookings WHERE date = date('now') AND status IN ('pending','confirmed') ORDER BY time")
        today = await cur.fetchall()
    if not today:
        await message.answer("📭 сегодня записей нет")
        return
    text = "📅 <b>записи на сегодня:</b>\n\n"
    for b in today:
        text += f"⏰ <b>{b['time']}</b> — {b['name']} ({b['service']}, {b['price']}₽)\n"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎛 открыть админ-панель", web_app=WebAppInfo(url=ADMIN_PANEL_URL))]
    ])
    await message.answer(text, reply_markup=kb, parse_mode="HTML")


# ============== FASTAPI APP ==============
@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    if bot and dp:
        try:
            await bot.set_chat_menu_button(menu_button=MenuButtonWebApp(
                text="✦ yu.nails",
                web_app=WebAppInfo(url=WEBAPP_URL)
            ))
            await bot.set_my_commands([
                BotCommand(command="start", description="начать"),
                BotCommand(command="bookings", description="мои записи"),
                BotCommand(command="cancel", description="отменить запись"),
                BotCommand(command="today", description="записи на сегодня (админ)"),
                BotCommand(command="admin", description="админ-панель"),
                BotCommand(command="addadmin", description="добавить админа"),
            ])
        except Exception as e:
            log.warning(f"Bot setup failed: {e}")

        asyncio.create_task(dp.start_polling(bot))
        log.info("Bot polling started")
        scheduler.add_job(send_reminders, 'interval', minutes=10)
        scheduler.start()
        log.info("Scheduler started")
    yield
    if bot:
        await bot.session.close()
    scheduler.shutdown()


app = FastAPI(title="yu.nails API", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ============== MODELS ==============
class BookingIn(BaseModel):
    id: Optional[int] = None
    service: str
    serviceId: Optional[str] = None
    design: str = ""
    designPrice: int = 0
    date: str
    time: str
    name: str
    username: Optional[str] = None
    tgId: int
    photoUrl: Optional[str] = None
    comment: str = ""
    price: int
    status: str = "pending"
    createdAt: str


class ServiceIn(BaseModel):
    id: str
    name: str
    price: int
    duration: int = 60
    description: str = ""
    is_addon: int = 0
    sort_order: int = 0
    active: int = 1


class ScheduleIn(BaseModel):
    day_of_week: int
    start_time: str
    end_time: str
    active: int = 1


class BlockSlotIn(BaseModel):
    date: str
    time: str
    reason: str = ""


class SettingsIn(BaseModel):
    default_start_time: Optional[str] = None
    default_end_time: Optional[str] = None
    slot_duration_min: Optional[str] = None
    booking_lead_hours: Optional[str] = None


# ============== HELPERS ==============
async def get_available_slots(date: str) -> List[str]:
    """Получить доступные слоты на дату (с учётом расписания, занятости и блокировок)"""
    # парсим дату
    try:
        d = datetime.fromisoformat(date)
    except ValueError:
        return []
    dow = d.weekday()  # 0=пн

    # берём расписание на этот день
    async with aiosqlite.connect(DATABASE) as db:
        cur = await db.execute("SELECT start_time, end_time, active FROM schedule WHERE day_of_week = ?", (dow,))
        row = await cur.fetchone()
    if not row or not row[2]:
        return []
    start_t, end_t, _ = row

    # получаем занятые
    async with aiosqlite.connect(DATABASE) as db:
        cur = await db.execute("SELECT time FROM bookings WHERE date = ? AND status IN ('pending','confirmed')", (date,))
        taken = {r[0] for r in await cur.fetchall()}
        cur = await db.execute("SELECT time FROM blocked_slots WHERE date = ?", (date,))
        blocked = {r[0] for r in await cur.fetchall()}

    # получаем длительность слота
    duration = int(await get_setting("slot_duration_min", "60"))
    lead_hours = int(await get_setting("booking_lead_hours", "2"))
    now = datetime.now()
    min_dt = now + timedelta(hours=lead_hours)

    slots = []
    sh, sm = map(int, start_t.split(':'))
    eh, em = map(int, end_t.split(':'))
    cur_dt = d.replace(hour=sh, minute=sm, second=0, microsecond=0)
    end_dt = d.replace(hour=eh, minute=em, second=0, microsecond=0)
    while cur_dt < end_dt:
        t = cur_dt.strftime("%H:%M")
        if t not in taken and t not in blocked:
            # проверка lead time
            if cur_dt >= min_dt:
                slots.append(t)
        cur_dt += timedelta(minutes=duration)
    return slots


# ============== PUBLIC ROUTES ==============
@app.get("/")
async def root():
    return {"status": "ok", "service": "yu.nails API"}


@app.get("/api/health")
async def health():
    return {"ok": True, "time": datetime.now().isoformat()}


@app.get("/api/schedule")
async def public_schedule():
    """Публичное расписание (для клиентской части)"""
    async with aiosqlite.connect(DATABASE) as db:
        cur = await db.execute("SELECT day_of_week, start_time, end_time, active FROM schedule ORDER BY day_of_week")
        rows = await cur.fetchall()
    schedule = [{"day": r[0], "start": r[1], "end": r[2], "active": bool(r[3])} for r in rows]
    start = await get_setting("default_start_time", "16:00")
    end = await get_setting("default_end_time", "21:00")
    duration = int(await get_setting("slot_duration_min", "60"))
    return {
        "schedule": schedule,
        "default_start": start,
        "default_end": end,
        "slot_duration": duration,
    }


@app.get("/api/services")
async def public_services():
    """Публичный список услуг"""
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM services WHERE active = 1 ORDER BY sort_order, id")
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


@app.get("/api/slots")
async def public_slots(date: str):
    """Доступные слоты на дату"""
    return {"date": date, "slots": await get_available_slots(date)}


@app.post("/api/bookings")
async def create_booking(b: BookingIn):
    """Создание новой записи"""
    # проверка что слот доступен
    slots = await get_available_slots(b.date)
    if b.time not in slots:
        raise HTTPException(status_code=400, detail="это время уже занято или недоступно")

    async with aiosqlite.connect(DATABASE) as db:
        cur = await db.execute("""
            INSERT INTO bookings (
                service, service_id, design, design_price,
                date, time, name, username, tg_id, photo_url,
                comment, price, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            b.service, b.serviceId, b.design, b.designPrice,
            b.date, b.time, b.name, b.username, b.tgId, b.photoUrl,
            b.comment, b.price, b.status, b.createdAt or datetime.now().isoformat()
        ))
        booking_id = cur.lastrowid
        await db.commit()

    log.info(f"New booking #{booking_id} from {b.name} — {b.service} on {b.date} at {b.time}")

    # уведомляем всех админов
    if bot:
        async with aiosqlite.connect(DATABASE) as db:
            cur = await db.execute("SELECT tg_id FROM admins")
            admin_ids = [r[0] for r in await cur.fetchall()]
        for admin_id in admin_ids:
            try:
                username_link = f"@{b.username}" if b.username else f"id{b.tgId}"
                text = (
                    f"🔔 <b>новая запись #{booking_id}</b>\n\n"
                    f"👤 <b>{b.name}</b> · {username_link}\n"
                    f"💅 {b.service}{' + ' + b.design + ' дизайн' if b.design else ''}\n"
                    f"📅 {b.date} в {b.time}\n"
                    f"💰 {b.price}₽\n"
                )
                if b.comment:
                    text += f"\n💬 <i>{b.comment}</i>\n"
                text += f"\n<a href='tg://user?id={b.tgId}'>написать клиенту →</a>"
                kb = InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="✅ подтвердить", callback_data=f"confirm:{booking_id}")],
                    [InlineKeyboardButton(text="❌ отменить", callback_data=f"reject:{booking_id}")],
                    [InlineKeyboardButton(text="🎛 админ-панель", web_app=WebAppInfo(url=ADMIN_PANEL_URL))],
                ])
                await bot.send_message(admin_id, text, parse_mode="HTML", reply_markup=kb)
            except Exception as e:
                log.error(f"Failed to notify admin {admin_id}: {e}")

    # уведомляем клиента
    if bot:
        try:
            date_human = datetime.fromisoformat(b.date).strftime("%d %B")
            weekday = ["понедельник","вторник","среда","четверг","пятница","суббота","воскресенье"][
                datetime.fromisoformat(b.date).weekday()
            ]
            await bot.send_message(
                b.tgId,
                f"✦ заявка принята!\n\n"
                f"<b>{b.service}</b>{' + ' + b.design + ' дизайн' if b.design else ''}\n"
                f"📅 {date_human} ({weekday}) в {b.time}\n"
                f"💰 {b.price}₽\n\n"
                f"мастер свяжется для подтверждения 💅",
                parse_mode="HTML"
            )
        except Exception as e:
            log.debug(f"Client notify failed: {e}")

    return {"ok": True, "id": booking_id}


@app.get("/api/bookings/{tg_id}")
async def get_user_bookings(tg_id: int):
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM bookings WHERE tg_id = ? ORDER BY date DESC, time DESC", (tg_id,))
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


@app.post("/api/bookings/{booking_id}/cancel")
async def cancel_booking(booking_id: int):
    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("UPDATE bookings SET status = 'cancelled' WHERE id = ?", (booking_id,))
        await db.commit()
    return {"ok": True}


# ============== ADMIN ROUTES ==============
async def get_admin(x_tg_id: int = Header(...)):
    if not await is_admin(x_tg_id):
        raise HTTPException(status_code=403, detail="not an admin")
    return x_tg_id


@app.get("/api/admin/check")
async def admin_check(x_tg_id: int = Header(...)):
    return {"is_admin": await is_admin(x_tg_id)}


@app.get("/api/admin/stats")
async def admin_stats(_: int = Depends(get_admin)):
    """Полная статистика для админ-панели"""
    today = datetime.now().date().isoformat()
    week_ago = (datetime.now() - timedelta(days=7)).date().isoformat()
    month_ago = (datetime.now() - timedelta(days=30)).date().isoformat()

    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row

        cur = await db.execute("SELECT COUNT(*) c FROM bookings")
        total = (await cur.fetchone())["c"]

        cur = await db.execute("SELECT COUNT(*) c FROM bookings WHERE date >= ?", (today,))
        today_count = (await cur.fetchone())["c"]

        cur = await db.execute("SELECT COUNT(*) c FROM bookings WHERE date >= ? AND status IN ('pending','confirmed')", (today,))
        upcoming = (await cur.fetchone())["c"]

        cur = await db.execute("SELECT COUNT(*) c FROM bookings WHERE status = 'pending'")
        pending = (await cur.fetchone())["c"]

        cur = await db.execute("SELECT COUNT(*) c FROM clients")
        clients_total = (await cur.fetchone())["c"]

        # выручка
        cur = await db.execute("SELECT COALESCE(SUM(price),0) s FROM bookings WHERE status IN ('confirmed','completed')")
        revenue_total = (await cur.fetchone())["s"]

        cur = await db.execute("SELECT COALESCE(SUM(price),0) s FROM bookings WHERE date >= ? AND status IN ('confirmed','completed')", (week_ago,))
        revenue_week = (await cur.fetchone())["s"]

        cur = await db.execute("SELECT COALESCE(SUM(price),0) s FROM bookings WHERE date >= ? AND status IN ('confirmed','completed')", (month_ago,))
        revenue_month = (await cur.fetchone())["s"]

        cur = await db.execute("SELECT COALESCE(SUM(price),0) s FROM bookings WHERE date = ? AND status IN ('confirmed','completed','pending')", (today,))
        revenue_today = (await cur.fetchone())["s"]

        # популярные услуги
        cur = await db.execute("""
            SELECT service, COUNT(*) c FROM bookings
            WHERE status != 'cancelled'
            GROUP BY service ORDER BY c DESC LIMIT 5
        """)
        popular = [{"service": r["service"], "count": r["c"]} for r in await cur.fetchall()]

        # записи на сегодня
        cur = await db.execute("""
            SELECT * FROM bookings WHERE date = ? ORDER BY time
        """, (today,))
        today_bookings = [dict(r) for r in await cur.fetchall()]

        # записи на завтра
        tomorrow = (datetime.now() + timedelta(days=1)).date().isoformat()
        cur = await db.execute("""
            SELECT * FROM bookings WHERE date = ? AND status IN ('pending','confirmed') ORDER BY time
        """, (tomorrow,))
        tomorrow_bookings = [dict(r) for r in await cur.fetchall()]

    return {
        "total_bookings": total,
        "today_count": today_count,
        "upcoming": upcoming,
        "pending": pending,
        "clients_total": clients_total,
        "revenue_total": revenue_total,
        "revenue_today": revenue_today,
        "revenue_week": revenue_week,
        "revenue_month": revenue_month,
        "popular_services": popular,
        "today_bookings": today_bookings,
        "tomorrow_bookings": tomorrow_bookings,
    }


@app.get("/api/admin/bookings")
async def admin_bookings(
    status: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    limit: int = 100,
    _: int = Depends(get_admin),
):
    """Все записи с фильтрами"""
    query = "SELECT * FROM bookings WHERE 1=1"
    params = []
    if status and status != "all":
        query += " AND status = ?"
        params.append(status)
    if date_from:
        query += " AND date >= ?"
        params.append(date_from)
    if date_to:
        query += " AND date <= ?"
        params.append(date_to)
    query += " ORDER BY date DESC, time DESC LIMIT ?"
    params.append(limit)
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(query, params)
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


@app.post("/api/admin/bookings/{booking_id}/status")
async def admin_change_status(booking_id: int, body: dict, _: int = Depends(get_admin)):
    new_status = body.get("status")
    if new_status not in ("pending", "confirmed", "cancelled", "completed"):
        raise HTTPException(400, "invalid status")
    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("UPDATE bookings SET status = ? WHERE id = ?", (new_status, booking_id))
        await db.commit()
    # уведомляем клиента
    if bot and new_status in ("confirmed", "cancelled"):
        async with aiosqlite.connect(DATABASE) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute("SELECT * FROM bookings WHERE id = ?", (booking_id,))
            b = await cur.fetchone()
        if b:
            try:
                if new_status == "confirmed":
                    await bot.send_message(b["tg_id"],
                        f"✅ <b>запись подтверждена!</b>\n\n"
                        f"💅 {b['service']}\n📅 {b['date']} в {b['time']}\n💰 {b['price']}₽\n\n"
                        f"жду тебя! ✦", parse_mode="HTML")
                elif new_status == "cancelled":
                    await bot.send_message(b["tg_id"],
                        f"😔 запись <b>{b['date']} в {b['time']}</b> отменена.\n"
                        f"запишись снова в любое время ✦", parse_mode="HTML")
            except: pass
    return {"ok": True}


@app.delete("/api/admin/bookings/{booking_id}")
async def admin_delete_booking(booking_id: int, _: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("DELETE FROM bookings WHERE id = ?", (booking_id,))
        await db.commit()
    return {"ok": True}


@app.post("/api/admin/block-slot")
async def admin_block_slot(body: BlockSlotIn, _: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        try:
            await db.execute("INSERT INTO blocked_slots (date, time, reason, created_at) VALUES (?, ?, ?, ?)",
                          (body.date, body.time, body.reason, datetime.now().isoformat()))
            await db.commit()
        except aiosqlite.IntegrityError:
            raise HTTPException(400, "слот уже заблокирован")
    return {"ok": True}


@app.delete("/api/admin/block-slot/{slot_id}")
async def admin_unblock_slot(slot_id: int, _: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("DELETE FROM blocked_slots WHERE id = ?", (slot_id,))
        await db.commit()
    return {"ok": True}


@app.get("/api/admin/blocked-slots")
async def admin_list_blocked(date: Optional[str] = None, _: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        if date:
            cur = await db.execute("SELECT * FROM blocked_slots WHERE date = ? ORDER BY time", (date,))
        else:
            cur = await db.execute("SELECT * FROM blocked_slots ORDER BY date DESC, time LIMIT 200")
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


# ============== SERVICES CRUD ==============
@app.get("/api/admin/services")
async def admin_list_services(_: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM services ORDER BY sort_order, id")
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


@app.post("/api/admin/services")
async def admin_create_service(s: ServiceIn, _: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        try:
            await db.execute("""
                INSERT INTO services (id, name, price, duration, description, is_addon, sort_order, active, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (s.id, s.name, s.price, s.duration, s.description, s.is_addon, s.sort_order, s.active, datetime.now().isoformat()))
            await db.commit()
        except aiosqlite.IntegrityError:
            raise HTTPException(400, "услуга с таким id уже есть")
    return {"ok": True}


@app.put("/api/admin/services/{service_id}")
async def admin_update_service(service_id: str, s: ServiceIn, _: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("""
            UPDATE services SET name=?, price=?, duration=?, description=?, is_addon=?, sort_order=?, active=?
            WHERE id=?
        """, (s.name, s.price, s.duration, s.description, s.is_addon, s.sort_order, s.active, service_id))
        await db.commit()
    return {"ok": True}


@app.delete("/api/admin/services/{service_id}")
async def admin_delete_service(service_id: str, _: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("DELETE FROM services WHERE id = ?", (service_id,))
        await db.commit()
    return {"ok": True}


# ============== SCHEDULE CRUD ==============
@app.get("/api/admin/schedule")
async def admin_list_schedule(_: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM schedule ORDER BY day_of_week")
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


@app.put("/api/admin/schedule")
async def admin_update_schedule(items: List[ScheduleIn], _: int = Depends(get_admin)):
    """Заменить всё расписание разом"""
    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("DELETE FROM schedule")
        for s in items:
            await db.execute("""
                INSERT INTO schedule (day_of_week, start_time, end_time, active)
                VALUES (?, ?, ?, ?)
            """, (s.day_of_week, s.start_time, s.end_time, s.active))
        await db.commit()
    return {"ok": True}


@app.put("/api/admin/settings")
async def admin_update_settings(body: SettingsIn, _: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        data = body.dict(exclude_none=True)
        for k, v in data.items():
            await db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (k, str(v)))
        await db.commit()
    return {"ok": True}


@app.get("/api/admin/settings")
async def admin_get_settings(_: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        cur = await db.execute("SELECT key, value FROM settings")
        rows = await cur.fetchall()
    return {r[0]: r[1] for r in rows}


@app.get("/api/admin/clients")
async def admin_list_clients(_: int = Depends(get_admin)):
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("""
            SELECT c.*,
              (SELECT COUNT(*) FROM bookings WHERE tg_id = c.tg_id AND status IN ('confirmed','completed')) as visits,
              (SELECT COALESCE(SUM(price),0) FROM bookings WHERE tg_id = c.tg_id AND status IN ('confirmed','completed')) as total_spent
            FROM clients c
            ORDER BY c.created_at DESC LIMIT 500
        """)
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


# ============== CALLBACKS (bot) ==============
@dp.callback_query(F.data.startswith("confirm:"))
async def on_confirm(callback: types.CallbackQuery):
    if not await is_admin(callback.from_user.id):
        return
    booking_id = int(callback.data.split(":")[1])
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM bookings WHERE id = ?", (booking_id,))
        booking = await cur.fetchone()
        if not booking:
            await callback.answer("запись не найдена", show_alert=True)
            return
        await db.execute("UPDATE bookings SET status = 'confirmed' WHERE id = ?", (booking_id,))
        await db.commit()
    await callback.answer("✅ подтверждено")
    try:
        await callback.message.edit_reply_markup(reply_markup=None)
    except: pass
    if bot:
        try:
            date_human = datetime.fromisoformat(booking["date"]).strftime("%d %B")
            await bot.send_message(booking["tg_id"],
                f"✅ <b>запись подтверждена!</b>\n\n"
                f"💅 {booking['service']}\n📅 {date_human} в {booking['time']}\n💰 {booking['price']}₽\n\n"
                f"жду тебя! ✦", parse_mode="HTML")
        except: pass


@dp.callback_query(F.data.startswith("reject:"))
async def on_reject(callback: types.CallbackQuery):
    if not await is_admin(callback.from_user.id):
        return
    booking_id = int(callback.data.split(":")[1])
    async with aiosqlite.connect(DATABASE) as db:
        await db.execute("UPDATE bookings SET status = 'cancelled' WHERE id = ?", (booking_id,))
        await db.commit()
    await callback.answer("❌ отклонено")
    try:
        await callback.message.edit_reply_markup(reply_markup=None)
    except: pass


# ============== REMINDERS ==============
async def send_reminders():
    if not bot: return
    now = datetime.now()
    async with aiosqlite.connect(DATABASE) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("""
            SELECT * FROM bookings
            WHERE status IN ('pending', 'confirmed')
            AND (notified_24h = 0 OR notified_2h = 0)
        """)
        bookings = await cur.fetchall()

    for b in bookings:
        try:
            booking_dt = datetime.fromisoformat(f"{b['date']}T{b['time']}:00")
            diff = (booking_dt - now).total_seconds() / 3600

            if 23 < diff < 25 and not b["notified_24h"]:
                try:
                    await bot.send_message(b["tg_id"],
                        f"💅 <b>напоминаем: завтра в {b['time']}</b>\n\n"
                        f"{b['service']}{' + ' + b['design'] + ' дизайн' if b['design'] else ''}\n"
                        f"📅 {b['date']}\nжду тебя! ✦", parse_mode="HTML")
                    async with aiosqlite.connect(DATABASE) as db2:
                        await db2.execute("UPDATE bookings SET notified_24h = 1 WHERE id = ?", (b["id"],))
                        await db2.commit()
                except: pass

            if 1.5 < diff < 2.5 and not b["notified_2h"]:
                try:
                    await bot.send_message(b["tg_id"],
                        f"⏰ <b>через 2 часа — маникюр!</b>\n\n"
                        f"{b['service']} в {b['time']}\n📅 {b['date']}\nне опаздывай ✦", parse_mode="HTML")
                    async with aiosqlite.connect(DATABASE) as db2:
                        await db2.execute("UPDATE bookings SET notified_2h = 1 WHERE id = ?", (b["id"],))
                        await db2.commit()
                except: pass
        except: pass


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
