/* ============================================================
   yu.nails — v4.0 (Telegram Mini App + Backend)
   ============================================================ */
(() => {
  'use strict';

  /* ============================================================
     UTILS
     ============================================================ */
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));
  const isCoarse = window.matchMedia('(pointer: coarse)').matches;
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const ruMonth = ['январь','февраль','март','апрель','май','июнь','июль','август','сентябрь','октябрь','ноябрь','декабрь'];
  const ruWeek = ['пн','вт','ср','чт','пт','сб','вс'];

  const throttle = (fn, ms = 16) => {
    let last = 0, id;
    return (...args) => {
      const now = Date.now();
      if (now - last >= ms) { last = now; fn(...args); }
      else { clearTimeout(id); id = setTimeout(() => { last = Date.now(); fn(...args); }, ms - (now - last)); }
    };
  };

  const formatPrice = (n) => `${n} ₽`;

  /* ============================================================
     TELEGRAM WEBAPP — инициализируем ДО всего остального
     ============================================================ */
  const tg = window.Telegram?.WebApp;
  let tgUser = null;
  const API_URL = window.YUNAILS_API || ''; // backend URL

  if (tg) {
    try {
      tg.ready();
      tg.expand();
      tgUser = tg.initDataUnsafe?.user || null;

      // применяем тему Telegram
      try {
        const tp = tg.themeParams || {};
        if (tp.bg_color) document.documentElement.style.setProperty('--bg', tp.bg_color);
        if (tp.text_color) document.documentElement.style.setProperty('--ink', tp.text_color);
        if (tp.hint_color) document.documentElement.style.setProperty('--ink-dim', tp.hint_color);
        if (tp.button_color) document.documentElement.style.setProperty('--accent', tp.button_color);
        if (tp.secondary_bg_color) document.documentElement.style.setProperty('--bg-2', tp.secondary_bg_color);
      } catch {}

      try { tg.HapticFeedback?.impactOccurred?.('light'); } catch {}
    } catch (e) {
      console.warn('TG init failed:', e);
    }
  }

  /* ============================================================
     CURSOR
     ============================================================ */
  const cursor = $('#cursor');
  const cursorDot = $('#cursorDot');
  const cursorGlow = $('#cursorGlow');
  const cursorText = cursor?.querySelector('.cursor-text');

  if (!isCoarse && cursor && cursorDot) {
    let mx = -100, my = -100, cx = -100, cy = -100, gx = -100, gy = -100;
    let targetType = null;

    document.addEventListener('mousemove', e => {
      mx = e.clientX; my = e.clientY;
      cursorDot.style.transform = `translate(${mx}px, ${my}px) translate(-50%, -50%)`;
    }, { passive: true });

    const loop = () => {
      cx += (mx - cx) * 0.2;
      cy += (my - cy) * 0.2;
      cursor.style.transform = `translate(${cx}px, ${cy}px) translate(-50%, -50%)`;
      // glow движется медленнее для трейл-эффекта
      gx += (mx - gx) * 0.08;
      gy += (my - gy) * 0.08;
      if (cursorGlow) {
        cursorGlow.style.transform = `translate(${gx}px, ${gy}px) translate(-50%, -50%)`;
        cursorGlow.style.opacity = '1';
      }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);

    document.addEventListener('mouseleave', () => {
      if (cursorGlow) cursorGlow.style.opacity = '0';
    });

    const setType = (type) => {
      if (type === targetType) return;
      targetType = type;
      cursor.classList.remove('hover', 'cta', 'link');
      if (cursorText) cursorText.textContent = '';
      if (!type) return;
      if (type === 'cta') { cursor.classList.add('cta'); if (cursorText) cursorText.textContent = 'click'; }
      else if (type === 'link') cursor.classList.add('link');
      else { cursor.classList.add('hover'); if (cursorText) cursorText.textContent = type; }
    };

    document.addEventListener('mouseover', e => {
      const el = e.target.closest('[data-cursor]');
      if (el) setType(el.dataset.cursor);
    });
    document.addEventListener('mouseout', e => {
      if (e.target.closest('[data-cursor]')) setType(null);
    });
  }

  /* ============================================================
     MAGNETIC BUTTONS
     ============================================================ */
  if (!isCoarse && !prefersReduced) {
    $$('.btn-magnetic').forEach(btn => {
      btn.addEventListener('mousemove', e => {
        const r = btn.getBoundingClientRect();
        const x = e.clientX - r.left - r.width / 2;
        const y = e.clientY - r.top - r.height / 2;
        btn.style.transform = `translate(${x * 0.2}px, ${y * 0.35}px)`;
      });
      btn.addEventListener('mouseleave', () => { btn.style.transform = ''; });
      btn.addEventListener('blur', () => { btn.style.transform = ''; });
    });
  }

  /* ============================================================
     PRELOADER
     ============================================================ */
  const preloader = $('#preloader');
  const loaderNum = $('#loaderNum');
  const loaderBar = $('#loaderBar');
  const loaderWords = $$('.pw', $('#loaderWords'));
  let progress = 0;
  let wordIdx = -1;
  const totalWords = loaderWords.length;

  const setWord = (idx) => {
    if (idx === wordIdx) return;
    if (wordIdx >= 0) loaderWords[wordIdx]?.classList.remove('active');
    wordIdx = idx;
    if (loaderWords[wordIdx]) loaderWords[wordIdx].classList.add('active');
  };

  const finishPreload = () => {
    if (!preloader) return;
    preloader.classList.add('hide');
    initHero();
    document.body.style.overflow = '';
  };

  if (prefersReduced) {
    if (preloader) preloader.classList.add('hide');
    if (loaderNum) loaderNum.textContent = '100';
    if (loaderBar) loaderBar.style.width = '100%';
    setWord(totalWords - 1);
    initHero();
  } else if (preloader) {
    document.body.style.overflow = 'hidden';
    const interval = setInterval(() => {
      progress += Math.random() * 12 + 4;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        setTimeout(finishPreload, 300);
      }
      if (loaderNum) loaderNum.textContent = Math.floor(progress);
      if (loaderBar) loaderBar.style.width = progress + '%';
      setWord(Math.min(Math.floor(progress / 22), totalWords - 1));
    }, 120);
    setTimeout(() => { if (!preloader.classList.contains('hide')) finishPreload(); }, 5000);
  }

  function initHero() {
    $$('.hero-title .hw').forEach((w, i) => {
      setTimeout(() => w.classList.add('in'), i * 80);
    });
  }

  /* ============================================================
     SCROLL PROGRESS BAR
     ============================================================ */
  const scrollBar = $('#scrollProgressBar');
  function updateScrollProgress() {
    if (!scrollBar) return;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const pct = docHeight > 0 ? (window.scrollY / docHeight) * 100 : 0;
    scrollBar.style.width = Math.min(100, Math.max(0, pct)) + '%';
  }
  window.addEventListener('scroll', throttle(updateScrollProgress, 16), { passive: true });
  updateScrollProgress();

  /* ============================================================
     HERO PARTICLES (летающие ✦)
     ============================================================ */
  const particlesRoot = $('#heroParticles');
  if (particlesRoot && !prefersReduced) {
    const variants = ['', 'v2', 'v3'];
    const symbols = ['✦', '✧', '◆', '◈', '◐', '✦'];
    const count = window.innerWidth < 700 ? 12 : 24;
    const frag = document.createDocumentFragment();
    for (let i = 0; i < count; i++) {
      const p = document.createElement('span');
      p.className = `particle ${variants[i % 3]}`;
      p.textContent = symbols[i % symbols.length];
      const size = 14 + Math.random() * 20;
      const left = Math.random() * 100;
      const dur = 15 + Math.random() * 20;
      const delay = -Math.random() * dur;
      p.style.cssText = `left:${left}%;font-size:${size}px;animation-duration:${dur}s;animation-delay:${delay}s;`;
      frag.appendChild(p);
    }
    particlesRoot.appendChild(frag);
  }

  /* ============================================================
     3D TILT на услугах (только десктоп с мышью)
     ============================================================ */
  if (!isCoarse && !prefersReduced) {
    $$('.service').forEach(card => {
      let raf = null;
      const onMove = (e) => {
        const r = card.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width - 0.5;
        const py = (e.clientY - r.top) / r.height - 0.5;
        if (raf) cancelAnimationFrame(raf);
        raf = requestAnimationFrame(() => {
          card.style.transform = `perspective(800px) rotateY(${px * 6}deg) rotateX(${-py * 6}deg) translateY(-4px)`;
        });
      };
      const onLeave = () => {
        if (raf) cancelAnimationFrame(raf);
        card.style.transform = '';
      };
      card.addEventListener('mousemove', onMove);
      card.addEventListener('mouseleave', onLeave);
    });
  }

  /* ============================================================
     NAV
     ============================================================ */
  const nav = $('.nav');
  const burger = $('#navBurger');
  const mobileMenu = $('#mobileMenu');

  $$('[data-scroll]').forEach(btn => {
    btn.addEventListener('click', e => {
      const t = $('#' + btn.dataset.scroll);
      if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth' }); }
    });
  });
  $$('[data-scroll-nav]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      const t = $('#' + a.dataset.scrollNav);
      burger?.classList.remove('open');
      mobileMenu?.classList.remove('open');
      burger?.setAttribute('aria-expanded', 'false');
      mobileMenu?.setAttribute('aria-hidden', 'true');
      if (t) t.scrollIntoView({ behavior: 'smooth' });
    });
  });
  burger?.addEventListener('click', () => {
    const open = !burger.classList.contains('open');
    burger.classList.toggle('open', open);
    mobileMenu?.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', String(open));
    mobileMenu?.setAttribute('aria-hidden', String(!open));
    document.body.style.overflow = open ? 'hidden' : '';
  });

  const updateNav = () => {
    if (!nav) return;
    const y = window.scrollY;
    if (y > 50) { nav.style.padding = '14px 40px'; nav.style.background = 'rgba(11, 10, 14, 0.85)'; }
    else { nav.style.padding = '20px 40px'; nav.style.background = 'rgba(11, 10, 14, 0.6)'; }
  };
  window.addEventListener('scroll', throttle(updateNav, 16), { passive: true });
  updateNav();

  /* ============================================================
     CASES — COVERFLOW CAROUSEL (стабильная, без лагов)
     ============================================================ */
  const CASES = [
    { num: '01', title: 'нюд', tag: 'new', img: 'cases/01-nude.jpeg', tags: ['покрытие', 'классика'] },
    { num: '02', title: 'яркий френч', tag: 'hot', img: 'cases/02-french.jpeg', tags: ['френч', 'дизайн'] },
    { num: '03', title: 'кошачий глаз', tag: 'new', img: 'cases/03-cat-eye.jpeg', tags: ['магнитный гель'] },
    { num: '04', title: 'дизайн с сердечками', tag: '', img: 'cases/04-hearts.jpeg', tags: ['слайдеры', 'дизайн'] },
    { num: '05', title: 'тёмный однотон', tag: 'hot', img: 'cases/05-dark.jpeg', tags: ['покрытие', 'бежевый'] },
    { num: '06', title: 'слайдеры', tag: '', img: 'cases/06-sliders.jpeg', tags: ['дизайн', 'надписи'] },
  ];
  const CASE_DESCRIPTIONS = [
    'нюдовый молочно-розовый оттенок, идеальная форма миндаль. базовый цвет, который подходит под всё.',
    'контрастный френч с яркой розовой полоской на кончиках. яркий, но не крикливый.',
    'магнитный гель-лак с эффектом кошачьего глаза — играет бликами на солнце и в свете ламп.',
    'нежный нюд в сочетании с белыми ногтями и синими сердечками-слайдерами. мило и со вкусом.',
    'глубокий тёплый бежевый однотон. строго, дорого, на все случаи жизни.',
    'нюдовое покрытие + слайдеры с надписями и фигурками. индивидуальный дизайн под настроение.',
  ];

  /* ---- Carousel state ---- */
  const stage = $('#carouselStage');
  const dotsEl = $('#carouselDots');
  const progressBar = $('#carouselProgress');
  const carousel = $('#carousel');
  const caseModal = $('#caseModal');

  let activeIdx = 0;
  let targetIdx = 0;
  let dragOffset = 0;
  let isDragging = false;
  let dragStartX = 0;
  let dragStartY = 0;
  let dragStartTime = 0;
  let dragAxisLocked = null; // 'x' | 'y' | null
  let slideW = 380;
  let slideEls = [];

  // autoplay
  let autoplayTimer = null;
  let autoplayStartedAt = 0;
  let autoplayPaused = false;
  let autoplayRemaining = 0; // ms remaining when paused
  const AUTOPLAY_MS = 6000;
  const SWIPE_THRESHOLD = 50;
  const VELOCITY_THRESHOLD = 0.3;

  const TOTAL = CASES.length;

  // таблица позиций (кольцо)
  const POS = {
    0:  { tx: 0,    tz: 0,   ry: 0,   s: 1,    op: 1,    z: 5 },
    1:  { tx: 0.7,  tz: -160, ry: -28, s: 0.88, op: 0.85, z: 4 },
    '-1':{ tx: -0.7, tz: -160, ry: 28,  s: 0.88, op: 0.85, z: 4 },
    2:  { tx: 1.1,  tz: -340, ry: -45, s: 0.72, op: 0.4,  z: 3 },
    '-2':{ tx: -1.1, tz: -340, ry: 45,  s: 0.72, op: 0.4,  z: 3 },
  };
  const POS_HIDDEN = { tx: 0, tz: -500, ry: 0, s: 0.5, op: 0, z: 1 };

  function ringOffset(i) {
    let o = i - targetIdx;
    const half = Math.floor(TOTAL / 2);
    if (o > half) o -= TOTAL;
    if (o < -half) o += TOTAL;
    return o;
  }

  function buildCarousel() {
    if (!stage) return;
    const frag = document.createDocumentFragment();
    CASES.forEach((c, i) => {
      const slide = document.createElement('div');
      slide.className = 'carousel-slide';
      slide.dataset.idx = String(i);
      slide.setAttribute('role', 'group');
      slide.setAttribute('aria-label', `${c.num} из ${TOTAL}: ${c.title}`);
      const tagHtml = c.tag ? `<span class="carousel-tag ${c.tag}">${c.tag}</span>` : '';
      const tagsHtml = c.tags.map(t => `<span class="carousel-tag">${t}</span>`).join('');
      slide.innerHTML = `
        <div class="carousel-slide-art">
          <img src="${c.img}" alt="${c.title}" loading="${i < 2 ? 'eager' : 'lazy'}" decoding="async" draggable="false" />
        </div>
        <div class="carousel-slide-tags">${tagHtml}${tagsHtml}</div>
        <div class="carousel-slide-info">
          <div>
            <div class="carousel-slide-num">${c.num}/${String(TOTAL).padStart(2, '0')}</div>
            <div class="carousel-slide-title">${c.title}</div>
          </div>
        </div>
      `;
      slide.addEventListener('click', (e) => {
        if (Math.abs(dragOffset) > 5) { e.stopPropagation(); return; }
        if (Math.abs(dragOffset) > 0) return;
        openCaseModal(i);
      });
      slide.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openCaseModal(i); }
      });
      slide.setAttribute('tabindex', '0');
      frag.appendChild(slide);
    });
    stage.innerHTML = '';
    stage.appendChild(frag);
    slideEls = Array.from(stage.children);

    if (dotsEl) {
      dotsEl.innerHTML = '';
      CASES.forEach((_, i) => {
        const dot = document.createElement('button');
        dot.type = 'button';
        dot.className = 'carousel-dot';
        dot.setAttribute('role', 'tab');
        dot.setAttribute('aria-label', `Перейти к кейсу ${i + 1}`);
        dot.addEventListener('click', (e) => { e.stopPropagation(); goTo(i); });
        dotsEl.appendChild(dot);
      });
    }
  }

  function applyTransforms(immediate) {
    if (immediate) {
      stage.style.transition = 'none';
      void stage.offsetHeight;
    } else {
      stage.style.transition = '';
    }
    for (let i = 0; i < slideEls.length; i++) {
      const slide = slideEls[i];
      const off = ringOffset(i);
      const pos = POS[off] || POS_HIDDEN;
      const tx = pos.tx * slideW + dragOffset;
      slide.style.transform = `translate3d(${tx}px,0,${pos.tz}px) rotateY(${pos.ry}deg) scale(${pos.s})`;
      slide.style.opacity = pos.op;
      slide.style.zIndex = pos.z;
      slide.classList.toggle('active', off === 0);
      slide.style.pointerEvents = off === 0 ? 'auto' : 'none';
    }
    if (immediate) requestAnimationFrame(() => { stage.style.transition = ''; });

    // ЖЁСТКОЕ обновление точек — снимаем .active со всех, ставим только нужной
    if (dotsEl) {
      const dots = dotsEl.children;
      for (let i = 0; i < dots.length; i++) {
        const isActive = i === targetIdx;
        if (isActive) {
          if (!dots[i].classList.contains('active')) dots[i].classList.add('active');
        } else {
          if (dots[i].classList.contains('active')) dots[i].classList.remove('active');
        }
      }
    }
  }

  function updateDots() {
    if (!dotsEl) return;
    const dots = dotsEl.children;
    for (let i = 0; i < dots.length; i++) {
      const isActive = i === targetIdx;
      if (isActive) dots[i].classList.add('active');
      else dots[i].classList.remove('active');
    }
  }

  function goTo(idx) {
    targetIdx = ((idx % TOTAL) + TOTAL) % TOTAL;
    dragOffset = 0;
    applyTransforms(false);
    updateDots();
    resetAutoplay();
  }

  // ---- drag/swipe ----
  function dragStart(e) {
    if (caseModal?.classList.contains('open')) return;
    if (e.target.closest('.carousel-dot')) return;
    isDragging = false; // пока не решили — это drag или scroll
    dragAxisLocked = null;
    dragStartX = (e.touches ? e.touches[0].clientX : e.clientX);
    dragStartY = (e.touches ? e.touches[0].clientY : e.clientY);
    dragStartTime = performance.now();
    dragOffset = 0;
    pauseAutoplay();
  }
  function dragMove(e) {
    if (caseModal?.classList.contains('open')) return;
    if (e.target.closest('.carousel-dot')) return;
    const x = (e.touches ? e.touches[0].clientX : e.clientX);
    const y = (e.touches ? e.touches[0].clientY : e.clientY);
    const dx = x - dragStartX;
    const dy = y - dragStartY;

    // определяем ось — только после 8px движения
    if (dragAxisLocked === null) {
      if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
        dragAxisLocked = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y';
        if (dragAxisLocked === 'x') {
          isDragging = true;
          stage.classList.add('dragging');
        } else {
          // это вертикальный скролл — не мешаем
          isDragging = false;
          return;
        }
      } else {
        return;
      }
    }

    if (dragAxisLocked === 'x') {
      dragOffset = dx;
      applyTransforms(true);
      if (e.cancelable) e.preventDefault();
    }
  }
  function dragEnd() {
    if (dragAxisLocked === 'x' && isDragging) {
      stage.classList.remove('dragging');
      const elapsed = performance.now() - dragStartTime;
      const velocity = Math.abs(dragOffset) / elapsed;
      if (Math.abs(dragOffset) > SWIPE_THRESHOLD || velocity > VELOCITY_THRESHOLD) {
        targetIdx += dragOffset < 0 ? 1 : -1;
        targetIdx = ((targetIdx % TOTAL) + TOTAL) % TOTAL;
        try { tg?.HapticFeedback?.impactOccurred?.('light'); } catch {}
      }
      dragOffset = 0;
      applyTransforms(false);
      updateDots();
    }
    isDragging = false;
    dragAxisLocked = null;
    dragOffset = 0;
    resetAutoplay();
  }

  function attachDrag() {
    if (!stage) return;
    stage.addEventListener('mousedown', dragStart);
    stage.addEventListener('touchstart', dragStart, { passive: true });
    // mousemove/up — на window, но только пока активно перетаскивание
    // (без этого потеряем событие если выйдем за stage)
    window.addEventListener('mousemove', (e) => { if (isDragging || dragAxisLocked) dragMove(e); });
    window.addEventListener('mouseup', (e) => { if (isDragging || dragAxisLocked) dragEnd(e); });
    stage.addEventListener('touchmove', dragMove, { passive: false });
    stage.addEventListener('touchend', dragEnd);
    stage.addEventListener('touchcancel', dragEnd);
  }

  // ---- autoplay ----
  function startAutoplay(fromMs) {
    if (autoplayTimer) clearInterval(autoplayTimer);
    autoplayStartedAt = performance.now();
    const target = fromMs || AUTOPLAY_MS;
    autoplayRemaining = target;
    autoplayPaused = false;
    if (progressBar) progressBar.style.width = '0';

    const TICK = 80;
    autoplayTimer = setInterval(() => {
      if (autoplayPaused) return;
      const elapsed = performance.now() - autoplayStartedAt;
      const pct = Math.min(100, (elapsed / autoplayRemaining) * 100);
      if (progressBar) progressBar.style.width = pct + '%';
      if (elapsed >= autoplayRemaining) {
        // листаем — только если пользователь не дёргает
        if (!isDragging) {
          targetIdx = (targetIdx + 1) % TOTAL;
          dragOffset = 0;
          applyTransforms(false);
          updateDots();
        }
        // перезапускаем
        autoplayStartedAt = performance.now();
        autoplayRemaining = AUTOPLAY_MS;
      }
    }, TICK);
  }
  function pauseAutoplay() {
    if (!autoplayTimer) return;
    autoplayRemaining -= performance.now() - autoplayStartedAt;
    autoplayPaused = true;
    if (progressBar) progressBar.style.width = '0';
  }
  function resetAutoplay() {
    if (!autoplayTimer) return;
    startAutoplay(AUTOPLAY_MS);
  }
  function stopAutoplay() {
    if (autoplayTimer) clearInterval(autoplayTimer);
    autoplayTimer = null;
    if (progressBar) progressBar.style.width = '0';
  }

  function attachAutoplayControl() {
    if (!carousel) return;
    carousel.addEventListener('mouseenter', pauseAutoplay);
    carousel.addEventListener('mouseleave', () => { if (!isDragging) resetAutoplay(); });
    if ('IntersectionObserver' in window) {
      const io = new IntersectionObserver(entries => {
        entries.forEach(e => {
          if (e.isIntersecting) resetAutoplay();
          else pauseAutoplay();
        });
      }, { threshold: 0.25 });
      io.observe(carousel);
    }
  }

  // ---- modal ----
  function openCaseModal(idx) {
    if (!caseModal) return;
    activeIdx = idx;
    const c = CASES[idx];
    const numEl = $('#caseModalNum');
    const titleEl = $('#caseModalTitle');
    const descEl = $('#caseModalDesc');
    const tagsEl = $('#caseModalTags');
    if (numEl) numEl.textContent = `${c.num}/${String(TOTAL).padStart(2, '0')}`;
    if (titleEl) titleEl.textContent = c.title;
    if (descEl) descEl.textContent = CASE_DESCRIPTIONS[idx];
    if (tagsEl) {
      const tags = [];
      if (c.tag) tags.push(`<span class="carousel-tag ${c.tag}">${c.tag}</span>`);
      c.tags.forEach(t => tags.push(`<span class="carousel-tag">${t}</span>`));
      tagsEl.innerHTML = tags.join('');
    }
    caseModal.classList.add('open');
    caseModal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    pauseAutoplay();
  }
  function closeCaseModal() {
    if (!caseModal) return;
    caseModal.classList.remove('open');
    caseModal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    resetAutoplay();
  }
  function attachModal() {
    if (!caseModal) return;
    $('.case-modal-close', caseModal)?.addEventListener('click', closeCaseModal);
    caseModal.addEventListener('click', e => { if (e.target === caseModal) closeCaseModal(); });
    $$('[data-case-close]', caseModal).forEach(b => b.addEventListener('click', closeCaseModal));
    document.addEventListener('keydown', e => {
      if (!caseModal.classList.contains('open')) return;
      if (e.key === 'Escape') closeCaseModal();
      if (e.key === 'ArrowLeft') { activeIdx = (activeIdx - 1 + TOTAL) % TOTAL; openCaseModal(activeIdx); }
      if (e.key === 'ArrowRight') { activeIdx = (activeIdx + 1) % TOTAL; openCaseModal(activeIdx); }
    });
  }

  // ---- keyboard ----
  function attachKeyboard() {
    document.addEventListener('keydown', e => {
      const tag = document.activeElement?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (caseModal?.classList.contains('open')) return;
      if (botModal?.classList.contains('open')) return;
      // стрелки работают в любом месте страницы, не только при фокусе в карусели
      if (e.key === 'ArrowLeft' && !e.ctrlKey && !e.metaKey) {
        // только если карусель видна
        const r = carousel?.getBoundingClientRect();
        if (r && r.bottom > 0 && r.top < window.innerHeight) {
          e.preventDefault();
          goTo(targetIdx - 1);
        }
      }
      if (e.key === 'ArrowRight' && !e.ctrlKey && !e.metaKey) {
        const r = carousel?.getBoundingClientRect();
        if (r && r.bottom > 0 && r.top < window.innerHeight) {
          e.preventDefault();
          goTo(targetIdx + 1);
        }
      }
    });
  }

  // ---- resize ----
  function handleResize() {
    if (slideEls[0]) slideW = slideEls[0].offsetWidth || 380;
    applyTransforms(true);
  }

  // init
  buildCarousel();
  attachDrag();
  attachKeyboard();
  attachAutoplayControl();
  attachModal();
  applyTransforms(true);
  if (!prefersReduced) startAutoplay();
  window.addEventListener('resize', throttle(handleResize, 200));

  if ('IntersectionObserver' in window) {
    const co = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); co.unobserve(e.target); } });
    }, { threshold: 0.15 });
    if (carousel) co.observe(carousel);
  } else {
    carousel?.classList.add('in');
  }

  /* ============================================================
     SERVICES / BOOKING STATE — загружаются с API если есть
     ============================================================ */
  let SERVICES = [
    { id: 'combo', name: 'комбинированный маникюр', price: 500, num: '01' },
    { id: 'cover', name: 'маникюр с покрытием', price: 1000, num: '02' },
    { id: 'fix', name: 'коррекция покрытия', price: 1200, num: '03' },
  ];
  // загружаем услуги и слоты с сервера
  (async () => {
    if (!API_URL) return;
    try {
      const r = await fetch(`${API_URL}/api/services`);
      if (r.ok) {
        const arr = await r.json();
        if (arr.length) {
          SERVICES = arr
            .filter(s => !s.is_addon && s.active)
            .sort((a, b) => a.sort_order - b.sort_order)
            .map((s, i) => ({ id: s.id, name: s.name, price: s.price, num: String(i + 1).padStart(2, '0') }));
          renderServiceOptions();
        }
      }
    } catch {}
  })();

  const state = {
    service: null,
    design: 0,
    designLabel: '',
    date: null,
    time: null,
    comment: '',
    calendarMonth: new Date(),
    bookings: loadBookings(),
  };

  function loadBookings() {
    try { return JSON.parse(localStorage.getItem('yunails_slots') || '{}'); } catch { return {}; }
  }
  const saveBookings = () => { try { localStorage.setItem('yunails_slots', JSON.stringify(state.bookings)); } catch {} };

  let currentStep = 1;

  function goStep(n) {
    if (n === 2 && !state.service) return showToast('выбери услугу');
    if (n === 3 && !state.date) return showToast('выбери дату');
    if (n === 4 && !state.time) return showToast('выбери время');
    currentStep = n;
    $$('.step-panel').forEach(p => p.classList.remove('active'));
    const target = $(`.step-panel[data-panel="${n}"]`);
    if (target) { target.classList.remove('active'); void target.offsetWidth; target.classList.add('active'); }
    $$('.step').forEach(s => {
      const sn = +s.dataset.step;
      s.classList.remove('active', 'done');
      if (sn === n) s.classList.add('active');
      else if (sn < n) s.classList.add('done');
    });
    if (n === 2) renderCalendar();
    if (n === 3) renderTimes();
    if (n === 4) { renderSummary(); fillTelegramProfile(); }
    if (n >= 2 && n <= 4) $('.booking-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  $$('[data-go]').forEach(b => b.addEventListener('click', () => goStep(+b.dataset.go)));

  /* STEP 1 */
  const serviceSelect = $('#serviceSelect');
  const designAddon = $('#designAddon');
  const totalNow = $('#totalNow');

  const renderServiceOptions = () => {
    if (!serviceSelect) return;
    const frag = document.createDocumentFragment();
    SERVICES.forEach(s => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'svc-option' + (state.service?.id === s.id ? ' selected' : '');
      btn.innerHTML = `<div class="svc-option-info"><span class="svc-option-num">${s.num}</span><span class="svc-option-name">${s.name}</span></div><span class="svc-option-price">${formatPrice(s.price)}</span>`;
      btn.addEventListener('click', () => {
        state.service = s;
        state.design = 0;
        state.designLabel = '';
        const r0 = $('input[name="design"][value="0"]:not([data-label])');
        if (r0) r0.checked = true;
        renderServiceOptions();
        renderAddon();
        updateTotal();
      });
      frag.appendChild(btn);
    });
    serviceSelect.innerHTML = '';
    serviceSelect.appendChild(frag);
  };
  const renderAddon = () => {
    if (!designAddon) return;
    const isBase = !!state.service && !state.service.addon;
    designAddon.hidden = !isBase;
  };
  $$('input[name="design"]').forEach(r => {
    r.addEventListener('change', e => { state.design = +e.target.value; state.designLabel = e.target.dataset.label || ''; updateTotal(); });
  });
  const updateTotal = () => {
    if (!totalNow) return;
    const base = state.service?.price || 0;
    totalNow.textContent = formatPrice(base + state.design);
  };
  renderServiceOptions();

  /* STEP 2: calendar */
  function renderCalendar() {
    const cal = $('#calendar');
    if (!cal) return;
    const cur = state.calendarMonth;
    const year = cur.getFullYear();
    const month = cur.getMonth();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const frag = document.createDocumentFragment();
    const nav = document.createElement('div');
    nav.className = 'cal-month-nav';
    const isCurrentMonth = year === today.getFullYear() && month === today.getMonth();
    nav.innerHTML = `
      <button class="cal-nav-btn" type="button" id="prevMonth" ${isCurrentMonth ? 'disabled' : ''} aria-label="Предыдущий месяц">←</button>
      <div class="cal-month">${ruMonth[month]} ${year}</div>
      <button class="cal-nav-btn" type="button" id="nextMonth" aria-label="Следующий месяц">→</button>
    `;
    frag.appendChild(nav);

    ruWeek.forEach(w => {
      const h = document.createElement('div');
      h.className = 'cal-head';
      h.textContent = w;
      frag.appendChild(h);
    });

    const firstDay = new Date(year, month, 1);
    let firstDow = firstDay.getDay();
    firstDow = firstDow === 0 ? 6 : firstDow - 1;
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    for (let i = 0; i < firstDow; i++) {
      const e = document.createElement('div');
      e.className = 'cal-day empty';
      frag.appendChild(e);
    }

    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, month, d);
      const cell = document.createElement('button');
      cell.type = 'button';
      cell.className = 'cal-day';
      cell.textContent = d;
      cell.setAttribute('aria-label', date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', weekday: 'long' }));
      if (date < today) { cell.classList.add('disabled'); cell.disabled = true; }
      else if (date.getDay() === 0 && !API_URL) { cell.classList.add('disabled'); cell.disabled = true; }
      else {
        // если есть API — проверим по расписанию
        cell.classList.add('available');
      }
      if (state.date && date.getTime() === state.date.getTime()) cell.classList.add('selected');
      if (cell.classList.contains('available')) {
        cell.addEventListener('click', () => { state.date = date; state.time = null; renderCalendar(); });
      }
      frag.appendChild(cell);
    }

    cal.innerHTML = '';
    cal.appendChild(frag);

    $('#prevMonth')?.addEventListener('click', () => { state.calendarMonth = new Date(year, month - 1, 1); renderCalendar(); });
    $('#nextMonth')?.addEventListener('click', () => { state.calendarMonth = new Date(year, month + 1, 1); renderCalendar(); });
  }

  /* STEP 3: times */
  const TIME_SLOTS_FALLBACK = ['10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'];
  let TIME_SLOTS = TIME_SLOTS_FALLBACK;

  function renderTimes() {
    const grid = $('#timeGrid');
    if (!grid) return;
    grid.innerHTML = '';
    if (!state.date) return;
    const hint = $('#dateHint');
    if (hint) hint.textContent = state.date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', weekday: 'long' });

    const key = state.date.toISOString().slice(0, 10);
    const taken = state.bookings[key] || [];

    // если есть API — загрузим реальные слоты
    if (API_URL) {
      fetch(`${API_URL}/api/slots?date=${key}`)
        .then(r => r.ok ? r.json() : null)
        .then(data => {
          if (data && Array.isArray(data.slots)) {
            TIME_SLOTS = data.slots;
            renderTimesGrid(taken);
          } else {
            renderTimesGrid(taken);
          }
        }).catch(() => renderTimesGrid(taken));
    } else {
      renderTimesGrid(taken);
    }
  }
  function renderTimesGrid(taken) {
    const grid = $('#timeGrid');
    if (!grid) return;
    grid.innerHTML = '';
    const frag = document.createDocumentFragment();
    TIME_SLOTS.forEach(t => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'time-slot';
      btn.textContent = t;
      btn.setAttribute('role', 'option');
      btn.setAttribute('aria-label', `Время ${t}`);
      const isTaken = taken.includes(t);
      if (isTaken) { btn.classList.add('taken'); btn.disabled = true; btn.setAttribute('aria-disabled', 'true'); }
      else {
        if (state.time === t) { btn.classList.add('selected'); btn.setAttribute('aria-selected', 'true'); }
        btn.addEventListener('click', () => { state.time = t; renderTimesGrid(taken); });
      }
      frag.appendChild(btn);
    });
    grid.appendChild(frag);
  }

  /* STEP 4: summary */
  function renderSummary() {
    const sum = $('#summary');
    if (!sum) return;
    if (!state.service || !state.date || !state.time) {
      sum.innerHTML = '<div class="summary-info">заполни все шаги</div>';
      return;
    }
    const total = state.service.price + state.design;
    const designTxt = state.designLabel ? ` + ${state.designLabel} дизайн` : '';
    const dateTxt = state.date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', weekday: 'short' });
    sum.innerHTML = `
      <div class="summary-info">
        <div>услуга: <b>${state.service.name}${designTxt}</b></div>
        <div>дата: <b>${dateTxt}, ${state.time}</b></div>
      </div>
      <div class="summary-price">${formatPrice(total)}</div>
    `;
  }

  /* ============================================================
     TG PROFILE IN STEP 4
     ============================================================ */
  const tgName = $('#tgName');
  const tgUsername = $('#tgUsername');
  const tgAvatar = $('#tgAvatar');

  function fillTelegramProfile() {
    if (tgUser && tgName && tgUsername) {
      const name = [tgUser.first_name, tgUser.last_name].filter(Boolean).join(' ') || 'клиент';
      tgName.textContent = name;
      tgUsername.textContent = tgUser.username ? '@' + tgUser.username : `id: ${tgUser.id}`;
      if (tgUser.photo_url && tgAvatar) {
        tgAvatar.style.backgroundImage = `url(${tgUser.photo_url})`;
        tgAvatar.textContent = '';
      } else if (tgAvatar) {
        tgAvatar.textContent = (tgUser.first_name || '?')[0].toUpperCase();
      }
    } else if (tgName) {
      tgName.textContent = tg ? 'загрузка...' : 'открой через бота';
      tgUsername.textContent = tg ? 'telegram' : 'нужен Telegram';
      if (tgAvatar) tgAvatar.textContent = '?';
    }
  }
  fillTelegramProfile();

  /* ============================================================
     SUBMIT — отправка на backend
     ============================================================ */
  $('#submitBtn')?.addEventListener('click', async e => {
    e.preventDefault();

    if (!tgUser) {
      showToast('открой через Telegram-бота');
      if (tg) tg.showAlert('Этот сайт работает только через Telegram-бота. Открой @yu_nails_bot');
      return;
    }
    if (!state.service || !state.date || !state.time) {
      showToast('заполни все шаги');
      return;
    }

    const commentEl = $('textarea[name="comment"]');
    const comment = commentEl ? commentEl.value.trim() : '';

    const booking = {
      id: Date.now(),
      service: state.service.name,
      serviceId: state.service.id,
      design: state.designLabel || '',
      designPrice: state.design,
      date: state.date.toISOString().slice(0, 10),
      time: state.time,
      name: [tgUser.first_name, tgUser.last_name].filter(Boolean).join(' '),
      username: tgUser.username || null,
      tgId: tgUser.id,
      photoUrl: tgUser.photo_url || null,
      comment,
      price: state.service.price + state.design,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    try { tg?.HapticFeedback?.impactOccurred?.('medium'); } catch {}

    let success = false;
    if (API_URL) {
      try {
        const res = await fetch(`${API_URL}/api/bookings`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(booking),
        });
        success = res.ok;
        if (!success) throw new Error('API ' + res.status);
      } catch (err) {
        console.error('API error:', err);
        showToast('ошибка отправки ✦');
        return;
      }
    } else {
      // fallback: localStorage
      const userBookings = loadUserBookings();
      userBookings.push(booking);
      saveUserBookings(userBookings);
      success = true;
      console.warn('API not configured — saved locally. Set window.YUNAILS_API in index.html');
    }

    if (success) {
      // бронируем слот
      const key = state.date.toISOString().slice(0, 10);
      if (!state.bookings[key]) state.bookings[key] = [];
      if (!state.bookings[key].includes(state.time)) state.bookings[key].push(state.time);
      saveBookings();

      try { tg?.HapticFeedback?.notificationOccurred?.('success'); } catch {}

      const total = state.service.price + state.design;
      const designTxt = state.designLabel ? ` + ${state.designLabel} дизайн` : '';
      const dateTxt = state.date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', weekday: 'long' });
      const usernameLine = tgUser.username
        ? `мастер свяжется с тобой в <b>@${tgUser.username}</b>`
        : `свяжусь через Telegram ✦`;
      const successText = $('#successText');
      if (successText) {
        successText.innerHTML =
          `${booking.name}, жду тебя <b>${dateTxt}</b> в <b>${state.time}</b><br>` +
          `${state.service.name}${designTxt} — <b>${formatPrice(total)}</b><br>` +
          `${usernameLine}<br>` +
          `<small style="color: var(--ink-soft); font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; font-family: var(--font-mono);">я напишу для подтверждения</small>`;
      }

      $$('.step-panel').forEach(p => p.classList.remove('active'));
      $('.step-panel[data-panel="5"]')?.classList.add('active');
      $$('.step').forEach(s => { s.classList.remove('active'); s.classList.add('done'); });
      $('.booking-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });

      // загружаем список записей для бота
      loadUserBookingsForBot();
    }
  });

  $('#newBooking')?.addEventListener('click', () => {
    state.service = null; state.design = 0; state.designLabel = '';
    state.date = null; state.time = null;
    const ta = $('textarea[name="comment"]');
    if (ta) ta.value = '';
    renderServiceOptions();
    updateTotal();
    goStep(1);
  });

  /* ============================================================
     USER BOOKINGS (для бота)
     ============================================================ */
  const USER_BOOKINGS_KEY = 'yunails_user_bookings';
  const CHAT_HISTORY_KEY = 'yunails_chat_history';
  const USER_NAME_KEY = 'yunails_user_name';

  function loadUserBookings() {
    try { return JSON.parse(localStorage.getItem(USER_BOOKINGS_KEY) || '[]'); } catch { return []; }
  }
  function saveUserBookings(arr) { try { localStorage.setItem(USER_BOOKINGS_KEY, JSON.stringify(arr)); } catch {} }
  function loadChatHistory() { try { return JSON.parse(localStorage.getItem(CHAT_HISTORY_KEY) || '[]'); } catch { return []; } }
  function saveChatHistory(arr) { try { localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(arr.slice(-50))); } catch {} }

  let userBookings = loadUserBookings();
  let chatHistory = loadChatHistory();

  if (tgUser) {
    try { localStorage.setItem(USER_NAME_KEY, tgUser.first_name || ''); } catch {}
  }

  // синхронизируем с backend если возможно
  async function loadUserBookingsForBot() {
    if (!API_URL || !tgUser) return;
    try {
      const res = await fetch(`${API_URL}/api/bookings/${tgUser.id}`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          userBookings = data;
          saveUserBookings(userBookings);
          renderBookings();
          renderLoyalty();
        }
      }
    } catch (e) { console.debug('load bookings failed:', e); }
  }
  loadUserBookingsForBot();

  /* ============================================================
     TOAST
     ============================================================ */
  const toastEl = $('#toast');
  let toastTimer;
  function showToast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2500);
  }

  /* ============================================================
     REVEAL ON SCROLL
     ============================================================ */
  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); revealObserver.unobserve(e.target); } });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    $$('[data-reveal]').forEach(el => revealObserver.observe(el));
  } else {
    $$('[data-reveal]').forEach(el => el.classList.add('in'));
  }

  /* ============================================================
     HERO PARALLAX
     ============================================================ */
  if (!isCoarse && !prefersReduced) {
    const heroSection = $('#hero');
    const cards = $$('.hero-card');
    if (heroSection && cards.length) {
      const onMove = throttle(e => {
        const r = heroSection.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        cards.forEach((c, i) => {
          const k = (i + 1) * 8;
          c.style.transform = `translate(${x * k}px, ${y * k}px) rotate(${i ? -4 : 3}deg)`;
        });
      }, 16);
      heroSection.addEventListener('mousemove', onMove, { passive: true });
      heroSection.addEventListener('mouseleave', () => {
        cards.forEach((c, i) => { c.style.transform = `rotate(${i ? -4 : 3}deg)`; });
      });
    }
  }

  /* ============================================================
     RIPPLE EFFECT
     ============================================================ */
  if (!prefersReduced) {
    // удаляем все висящие span'ы при отпускании чтобы не копились
    $$('.btn-primary, .nav-cta, .svc-option, .time-slot, .cal-day.available').forEach(el => {
      const POS_OVERRIDE = el.classList.contains('svc-option') || el.classList.contains('time-slot') || el.classList.contains('cal-day') || el.classList.contains('carousel-dot') || el.classList.contains('bot-tab');
      if (POS_OVERRIDE) el.style.position = 'relative';
      el.style.overflow = 'hidden';
      el.addEventListener('pointerdown', function (e) {
        const r = this.getBoundingClientRect();
        const ripple = document.createElement('span');
        const size = Math.max(r.width, r.height) * 2;
        ripple.style.cssText = `position:absolute; border-radius:50%; pointer-events:none; background: rgba(255,255,255,0.3); transform: translate(-50%,-50%) scale(0); width:${size}px; height:${size}px; left:${e.clientX - r.left}px; top:${e.clientY - r.top}px; animation: ripple .6s ease-out forwards; z-index: 10;`;
        this.appendChild(ripple);
        setTimeout(() => ripple.remove(), 700);
      });
    });
    if (!document.getElementById('ripple-kf')) {
      const s = document.createElement('style');
      s.id = 'ripple-kf';
      s.textContent = `@keyframes ripple { to { transform: translate(-50%,-50%) scale(1); opacity: 0; } }`;
      document.head.appendChild(s);
    }
  }

  /* ============================================================
     BOT MODAL
     ============================================================ */
  const botModal = $('#botModal');
  const botFab = $('#botFab');
  const botMessages = $('#botMessages');
  const botQuick = $('#botQuick');
  const botInput = $('#botInput');
  const botInputForm = $('#botInputForm');
  const bookingsList = $('#bookingsList');
  const loyaltyNum = $('#loyaltyNum');
  const loyaltyFill = $('#loyaltyFill');
  const loyaltyLeft = $('#loyaltyLeft');

  let lastFocusedBeforeBot = null;
  let lastBotTab = 'chats';

  function openBot(tab) {
    if (!botModal) return;
    tab = tab || lastBotTab;
    lastBotTab = tab;
    lastFocusedBeforeBot = document.activeElement;
    botModal.hidden = false;
    requestAnimationFrame(() => botModal.classList.add('open'));
    botModal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    switchTab(tab);
    setTimeout(() => botInput?.focus(), 400);
  }
  function closeBot() {
    if (!botModal) return;
    botModal.classList.remove('open');
    botModal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    setTimeout(() => { botModal.hidden = true; }, 300);
    if (lastFocusedBeforeBot?.focus) lastFocusedBeforeBot.focus();
  }
  function switchTab(tab) {
    $$('.bot-tab').forEach(t => { const a = t.dataset.tab === tab; t.classList.toggle('active', a); t.setAttribute('aria-selected', String(a)); });
    $$('.bot-pane').forEach(p => p.classList.toggle('active', p.dataset.pane === tab));
    // ленивый рендер — только когда открыли вкладку
    if (tab === 'bookings') renderBookings();
    if (tab === 'loyalty') renderLoyalty();
    if (tab === 'chats' && chatHistory.length === 0) {
      const name = tgUser?.first_name || localStorage.getItem(USER_NAME_KEY) || '';
      addBotMessage(name ? `привет, ${name}! ✦` : 'привет! ✦');
      addBotMessage('я — бот-помощник yu.nails. помогу записаться, покажу твои записи и бонусы');
      addBotMessage('что хочешь сделать?', false);
      renderQuickReplies();
    }
  }

  botFab?.addEventListener('click', () => openBot('chats'));
  $$('[data-bot-close]').forEach(el => el.addEventListener('click', closeBot));
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && botModal?.classList.contains('open')) closeBot(); });
  $$('.bot-tab').forEach(t => t.addEventListener('click', () => switchTab(t.dataset.tab)));

  function addBotMessage(text, save = true) {
    if (!botMessages) return;
    const wrap = document.createElement('div');
    wrap.style.cssText = 'display:flex;flex-direction:column;align-items:flex-start;';
    const msg = document.createElement('div');
    msg.className = 'msg msg-bot';
    msg.textContent = text;
    const time = document.createElement('div');
    time.className = 'msg-time';
    time.textContent = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    wrap.appendChild(msg); wrap.appendChild(time);
    botMessages.appendChild(wrap);
    botMessages.scrollTop = botMessages.scrollHeight;
    if (save) { chatHistory.push({ role: 'bot', text, time: Date.now() }); saveChatHistory(chatHistory); }
  }
  function addUserMessage(text) {
    if (!botMessages) return;
    const wrap = document.createElement('div');
    wrap.style.cssText = 'display:flex;flex-direction:column;align-items:flex-end;';
    const msg = document.createElement('div');
    msg.className = 'msg msg-user';
    msg.textContent = text;
    wrap.appendChild(msg);
    botMessages.appendChild(wrap);
    botMessages.scrollTop = botMessages.scrollHeight;
    chatHistory.push({ role: 'user', text, time: Date.now() });
    saveChatHistory(chatHistory);
  }

  const BOT_RESPONSES = {
    'записаться': () => { addBotMessage('отлично! записываю тебя ✦'); setTimeout(() => { closeBot(); $('#booking')?.scrollIntoView({ behavior: 'smooth' }); }, 800); },
    'мои записи': () => switchTab('bookings'),
    'бонусы': () => switchTab('loyalty'),
    'напомни': () => addBotMessage('напоминания приходят в Telegram автоматически: за день и за 2 часа до визита 🔔'),
    'отменить': () => { addBotMessage('открой вкладку «записи» — там можно отменить ✦'); setTimeout(() => switchTab('bookings'), 600); },
    'прайс': () => addBotMessage('комби маникюр — 500₽, с покрытием — 1000₽, коррекция — 1200₽. дизайн: лёгкий бесплатно, сложный +200₽ 💅'),
    'контакты': () => addBotMessage('tg: @yu_nails · адрес: ул. Красивых Ногтей, 1'),
    'привет': () => { const n = tgUser?.first_name || localStorage.getItem(USER_NAME_KEY); addBotMessage(n ? `привет, ${n}! ✦ рада тебя видеть` : 'привет! ✦'); },
    'default': (userText) => {
      const t = userText.toLowerCase();
      if (t.includes('запис') || t.includes('свобод')) return BOT_RESPONSES['записаться']();
      if (t.includes('бонус') || t.includes('скидк')) return BOT_RESPONSES['бонусы']();
      if (t.includes('напомин') || t.includes('уведом')) return BOT_RESPONSES['напомни']();
      if (t.includes('отмен') || t.includes('удал')) return BOT_RESPONSES['отменить']();
      if (t.includes('цен') || t.includes('сто') || t.includes('прайс')) return BOT_RESPONSES['прайс']();
      if (t.includes('контакт') || t.includes('адрес') || t.includes('телефон')) return BOT_RESPONSES['контакты']();
      if (t.includes('прив') || t.includes('здравств')) return BOT_RESPONSES['привет']();
      addBotMessage('я пока не понимаю, но учусь! попробуй кнопки ниже или спроси про запись, бонусы, прайс 💅');
    }
  };
  const QUICK_REPLIES = ['записаться', 'мои записи', 'бонусы', 'напомни', 'прайс', 'контакты'];

  function renderQuickReplies() {
    if (!botQuick) return;
    botQuick.innerHTML = '';
    QUICK_REPLIES.forEach(text => {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = text;
      b.addEventListener('click', () => handleUserMessage(text));
      botQuick.appendChild(b);
    });
  }
  function handleUserMessage(text) {
    if (!text?.trim()) return;
    addUserMessage(text);
    const key = text.toLowerCase().trim();
    const handler = BOT_RESPONSES[key] || BOT_RESPONSES['default'];
    setTimeout(() => handler(text), 400);
  }
  botInputForm?.addEventListener('submit', e => {
    e.preventDefault();
    const v = botInput?.value?.trim();
    if (!v) return;
    handleUserMessage(v);
    botInput.value = '';
  });

  function renderBookings() {
    if (!bookingsList) return;
    const now = new Date();
    const upcoming = userBookings.filter(b => (b.status === 'pending' || b.status === 'upcoming' || b.status === 'confirmed') && new Date(b.date + 'T' + b.time) >= now).sort((a, b) => new Date(a.date + 'T' + a.time) - new Date(b.date + 'T' + b.time));
    const past = userBookings.filter(b => b.status === 'completed' || (b.status !== 'cancelled' && new Date(b.date + 'T' + b.time) < now)).sort((a, b) => new Date(b.date + 'T' + b.time) - new Date(a.date + 'T' + a.time));

    if (userBookings.length === 0) {
      bookingsList.innerHTML = `<div class="bookings-empty"><div class="bookings-empty-icon">✦</div><div>у тебя пока нет записей</div><div style="margin-top: 8px; font-size: 12px;">нажми кнопку ниже</div></div>`;
      return;
    }

    bookingsList.innerHTML = '';
    const renderItem = (b) => {
      const item = document.createElement('div');
      const isPast = b.status === 'completed' || b.status === 'cancelled';
      item.className = `booking-item ${isPast ? 'completed' : 'upcoming'}`;
      const d = new Date(b.date);
      const dateTxt = d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', weekday: 'short' });
      const designTxt = b.design ? ` + ${b.design} дизайн` : '';
      const statusTxt = b.status === 'completed' ? '✓ было' : b.status === 'cancelled' ? '✕ отменено' : b.status === 'confirmed' ? '✓ подтверждено' : '⏳ ожидает';
      item.innerHTML = `
        <div class="booking-item-head">
          <div class="booking-item-date">${dateTxt}<small>${b.time} · ${b.service}${designTxt}</small></div>
          <span class="booking-item-status">${statusTxt}</span>
        </div>
        <div class="booking-item-info"><b>${formatPrice(b.price)}</b>${b.comment ? ' · ' + b.comment : ''}</div>
        ${!isPast ? `<div class="booking-item-actions"><button class="booking-action" data-action="reschedule" data-id="${b.id}">перенести</button><button class="booking-action danger" data-action="cancel" data-id="${b.id}">отменить</button></div>` : ''}
      `;
      bookingsList.appendChild(item);
    };

    if (upcoming.length) {
      const h = document.createElement('div');
      h.style.cssText = 'font-family: var(--font-mono); font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--ink-dim); margin: 8px 0 4px; padding: 0 4px;';
      h.textContent = 'предстоящие';
      bookingsList.appendChild(h);
      upcoming.forEach(renderItem);
    }
    if (past.length) {
      const h = document.createElement('div');
      h.style.cssText = 'font-family: var(--font-mono); font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--ink-dim); margin: 16px 0 4px; padding: 0 4px;';
      h.textContent = 'история';
      bookingsList.appendChild(h);
      past.slice(0, 10).forEach(renderItem);
    }

    bookingsList.querySelectorAll('.booking-action').forEach(b => {
      b.addEventListener('click', async () => {
        const id = +b.dataset.id;
        const action = b.dataset.action;
        if (action === 'cancel') {
          if (confirm('отменить запись?')) {
            if (API_URL) {
              try { await fetch(`${API_URL}/api/bookings/${id}/cancel`, { method: 'POST' }); } catch {}
            }
            const idx = userBookings.findIndex(x => x.id === id);
            if (idx >= 0) { userBookings[idx].status = 'cancelled'; saveUserBookings(userBookings); }
            addBotMessage('запись отменена ✦');
            renderBookings();
            showToast('запись отменена');
          }
        } else if (action === 'reschedule') {
          closeBot();
          $('#booking')?.scrollIntoView({ behavior: 'smooth' });
        }
      });
    });
  }

  function renderLoyalty() {
    if (!loyaltyNum) return;
    const now = new Date();
    // completed = подтверждённые И уже прошедшие (всё уникально, без двойного счёта)
    const completed = userBookings.filter(b => b.status === 'completed' ||
      (b.status !== 'cancelled' && new Date(b.date + 'T' + b.time) < now)
    ).length;
    const cyclePos = completed % 5;
    const next = cyclePos === 0 && completed > 0 ? 0 : 5 - cyclePos;
    loyaltyNum.textContent = completed;
    if (loyaltyFill) loyaltyFill.style.width = (cyclePos / 5 * 100) + '%';
    if (loyaltyLeft) loyaltyLeft.textContent = next;
  }

  if (chatHistory.length > 0 && botMessages) {
    botMessages.innerHTML = '';
    chatHistory.forEach(m => {
      if (m.role === 'bot') addBotMessage(m.text, false);
      else if (m.role === 'user') addUserMessage(m.text);
    });
    setTimeout(renderQuickReplies, 100);
  }

  /* ============================================================
     SERVICE WORKER
     ============================================================ */
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    try { navigator.serviceWorker.register('./sw.js', { scope: './' }).catch(() => {}); } catch {}
  }

  /* ============================================================
     TG BACK BUTTON — настраиваем в конце, когда все функции готовы
     ============================================================ */
  if (tg) {
    try {
      tg.BackButton.show();
      tg.BackButton.onClick(() => {
        if ($('#botModal')?.classList.contains('open')) closeBot();
        else if ($('#caseModal')?.classList.contains('open')) closeCaseModal();
        else if (tg.close) tg.close();
      });
    } catch (e) { /* noop */ }
  }

})();
