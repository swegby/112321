# yu.nails — Telegram Mini App

Полноценный сайт + Telegram-бот для записи на маникюр с автоматическими напоминаниями + **админ-панель**.

## 🏗 Структура

```
yu-nails/
├── index.html              # главный сайт (Mini App для клиентов)
├── admin.html              # АДМИН-ПАНЕЛЬ (Mini App для мастера)
├── admin.css               # стили админки
├── admin.js                # логика админки
├── styles.css              # стили сайта
├── script.js               # логика фронта
├── sw.js, manifest.json    # PWA
├── bot.html                # инструкция
├── backend/
│   ├── bot.py              # FastAPI + Telegram Bot
│   ├── requirements.txt
│   └── .env.example
```

## 🚀 Быстрый старт

### 1. Создай Telegram-бота

1. Открой [@BotFather](https://t.me/BotFather) в Telegram
2. `/newbot` → дай имя и username
3. Скопируй **токен** (вида `123456:ABC-DEF...`)
4. Узнай свой **telegram id** через [@userinfobot](https://t.me/userinfobot)

### 2. Настрой backend

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Linux/Mac
# или: venv\Scripts\activate  # Windows
pip install -r requirements.txt
cp .env.example .env
```

Открой `.env` и заполни:
```env
BOT_TOKEN=123456:ABC-DEF...
WEBAPP_URL=https://your-domain.com
ADMIN_TG_ID=123456789
```

### 3. Задеплой сайт (нужен HTTPS!)

Mini App работает только по HTTPS. Варианты:

**A) Render (бесплатно):**
1. Залей код на GitHub
2. Создай Web Service на [render.com](https://render.com)
3. Build: `pip install -r backend/requirements.txt`
4. Start: `cd backend && python bot.py`

**B) Railway:**
1. Зай на [railway.app](https://railway.app)
2. New Project → Deploy from GitHub
3. Добавь env-переменные

**C) Свой сервер:**
```bash
pip install -r backend/requirements.txt
cd backend && python bot.py
# или через gunicorn:
gunicorn backend.bot:app -w 1 -k uvicorn.workers.UvicornWorker
```

### 4. Укажи URL сайта в `index.html`

Добавь **перед** `<script src="script.js">`:
```html
<script>window.YUNAILS_API = 'https://your-api.onrender.com';</script>
```

### 5. Подключи WebApp к боту

1. Открой @BotFather
2. `/setdomain` → укажи свой домен
3. `/newapp` → выбери бота → укажи URL сайта

## 🎛 Админ-панель (отдельно от клиентского Mini App)

Файл `admin.html` открывается как второй Mini App в боте. Доступ только у админов.

**Возможности:**
- 📊 **Дашборд**: выручка (сегодня / неделя / месяц / всего), записи, клиенты, популярные услуги
- 📅 **Записи**: все записи с фильтрами, подтверждение/отмена, кнопка «написать клиенту»
- 🕐 **Расписание**: настройка часов для каждого дня недели
- 💅 **Услуги**: CRUD — создание, редактирование цен, удаление
- 🚫 **Блокировки**: заблокировать конкретные слоты
- 👥 **Клиенты**: база с визитами и суммой
- ⚙️ **Настройки**: часы, длительность слота, lead-time

**Доступ:**
- `ADMIN_TG_ID` в `.env` — главный админ
- `/addadmin @username` — добавить ещё админа
- `/deladmin @username` — удалить

## 🕐 Расписание по умолчанию

**Запись только с 16:00 до 21:00.** Меняется в админке → Расписание / Настройки. Воскресенье — выходной.

## 💡 Что умеет бот

### Клиенту:
- 📅 Запись через Mini App (только в рабочие часы)
- 🔔 Напоминания за 24ч и 2ч до визита
- 📋 Команда `/bookings` — список своих записей
- ❌ Команда `/cancel` — отмена последней записи
- 💬 Бот-виджет в приложении (чат, бонусы)

### Мастеру (админу):
- 🔔 Уведомление о новой записи + кнопки ✅/❌
- 👤 Ссылка на клиента `tg://user?id=...`
- 📊 `/admin` — открыть админ-панель
- 📅 `/today` — записи на сегодня
- 👥 `/addadmin @username` — добавить админа

## 🎨 Кастомизация

- **Стили**: `styles.css` (CSS-переменные в `:root`)
- **Услуги**: массив `SERVICES` в `script.js`
- **Цены**: можно поменять в HTML
- **Брендинг**: замени `yu.nails` в `index.html`

## 📞 Контакты клиента парсятся автоматически

Когда клиент открывает сайт через бота, из Telegram приходят:
- `first_name` + `last_name` → отображаются как имя
- `username` → мастер получает ссылку `@username`
- `tg_id` → мастер может написать через `tg://user?id=...`
- `photo_url` → аватарка в карточке брони

Клиенту **не нужно вводить контакты вручную**.

## 🐛 Troubleshooting

- **Бот не отвечает**: проверь `BOT_TOKEN` в `.env`
- **WebApp не открывается**: проверь HTTPS и `WEBAPP_URL`
- **Нет уведомлений**: мастер должен запустить `/start` в боте первый раз
- **CORS ошибки**: добавь свой домен в `allow_origins`

## 📝 Лицензия

Сделано для yu.nails · 2026
